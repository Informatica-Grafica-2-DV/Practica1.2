#include "Resources.h"

vector<Resources::ImageInfo> Resources::images_{
		{BaldosaC, "../Bmps/baldosaC.bmp"},
		{BaldosaF, "../Bmps/baldosaF.bmp"},
		{BaldosaP, "../Bmps/baldosaP.bmp"},
		{Container, "../Bmps/container.bmp"},
		{Grass, "../Bmps/grass.bmp"},
		{PapelC, "../Bmps/papelC.bmp"},
		{PapelE, "../Bmps/papelE.bmp"},
		{WindowC, "../Bmps/windowC.bmp"},
		{WindowV,"../Bmps/windowV.bmp"},
		{Zelda, "../Bmps/Zelda.bmp"}
};